/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int rodada =1;
    int pontuação;
    int total =0;
    
    while(rodada <=3){
        printf("digite os pontos da rodada %d: ", rodada);
        scanf("%d", &pontuação);
        
        rodada++;
        total = total + pontuação;
        
    }
    
    printf("o valor total de pontos é: %d", total);
    return 0;
}
